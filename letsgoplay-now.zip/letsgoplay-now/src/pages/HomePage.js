import React, { useState } from 'react';

const texts = {
  en: {
    title: "Let's Go Play!",
    create: "Create Activity",
    join: "Join Activity",
    switch: "切换到中文"
  },
  zh: {
    title: "一起出去玩吧！",
    create: "创建活动",
    join: "接龙报名",
    switch: "Switch to English"
  }
};

function HomePage() {
  const [lang, setLang] = useState('en');
  const t = texts[lang];

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>{t.title}</h1>
      <button>{t.create}</button>
      <button>{t.join}</button>
      <br/><br/>
      <button onClick={() => setLang(lang === 'en' ? 'zh' : 'en')}>{t.switch}</button>
    </div>
  );
}

export default HomePage;